<?php
    //Lab 1.1
    //Name: Edwin Chen
    echo "<h1>Question 1</h1>";

    //Question 1A
    echo "<p>Hello World</p>";
?>